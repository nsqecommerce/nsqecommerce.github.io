class HelloWorld:

    def __call__(self) -> str:
        hello = 'Hello, TaskHuman!'
        print(hello)
        return hello
